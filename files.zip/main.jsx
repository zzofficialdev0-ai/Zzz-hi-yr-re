import React from 'react'
import ReactDOM from 'react-dom/client'
import Z1JobPlatform from './z1-job-platform.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Z1JobPlatform />
  </React.StrictMode>,
)
