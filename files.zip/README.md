# Z1 JOB - Premium Luxury Earning Platform

A full-stack luxury dark-golden themed task-based earning platform with Firebase backend, payment integration, fraud detection, and multi-currency support.

## 🌟 Features

### User Features
- ✨ 6-tier subscription plans (Free to Lifetime Exclusive)
- 💰 Multiple earning opportunities (Social tasks, likes, shares, downloads)
- 💳 Multiple withdrawal methods (Paiker, JazzCash, Easypaisa, Bank, PayPal)
- 📊 Real-time earnings dashboard
- 🎯 Task tracking and history
- 🔒 Secure authentication with JWT
- 🌍 Multi-currency and multi-language support

### Advertiser Features
- 📢 Campaign creation and management
- 📈 Real-time analytics and tracking
- 🎯 Target audience by country
- 💰 Budget management with visual progress
- 🔍 Fraud detection insights
- ⚡ 20 companion plans (Rs 500 - Rs 70,000)

### Admin Features
- 👥 Complete user management
- 💸 Withdrawal approval system
- 📊 Platform-wide analytics
- 🚫 Fraud detection and user suspension
- 📝 Activity logs and reporting
- 🎨 Plan and campaign control

## 🎨 Design Theme

**Luxury Dark-Golden Premium**
- Background: #0D0D0D (Deep Black)
- Gold Gradient: #C9A227 → #FFD700
- Typography: Poppins Bold (headings), Inter Regular (body)
- Animations: Hover pulse, scroll fade-in, glowing effects
- Premium badges and VIP indicators

## 🏗️ Tech Stack

- **Frontend**: React 18 with Hooks
- **Backend**: Firebase (Authentication, Realtime Database)
- **Charts**: Recharts
- **Payments**: Paiker Payment Gateway
- **Ads**: Google AdMob
- **Security**: bcrypt, AES-256, JWT

## 📦 Installation

### Prerequisites
- Node.js 16+ and npm
- Firebase account
- Paiker account (for payments)
- Google AdMob account

### Setup Steps

1. **Clone and Install**
```bash
npm create vite@latest z1-job -- --template react
cd z1-job
npm install
npm install firebase recharts
```

2. **Configure Firebase**
- Create a Firebase project at https://console.firebase.google.com
- Enable Authentication (Email/Password)
- Enable Realtime Database
- Copy the configuration (already included in the code)

3. **Set up Firebase Security Rules**

Realtime Database Rules:
```json
{
  "rules": {
    "users": {
      "$uid": {
        ".read": "$uid === auth.uid || root.child('users').child(auth.uid).child('isAdmin').val() === true",
        ".write": "$uid === auth.uid || root.child('users').child(auth.uid).child('isAdmin').val() === true"
      }
    },
    "tasks": {
      ".read": "auth != null",
      ".write": "auth != null"
    },
    "withdrawals": {
      ".read": "auth != null",
      ".write": "auth != null"
    },
    "campaigns": {
      ".read": "auth != null",
      ".write": "auth != null"
    }
  }
}
```

4. **Configure Paiker Payment**
- Sign up at https://paiker.site
- Get API keys from dashboard
- Update PAIKER_CONFIG in the code (keep secret key server-side!)

5. **Set up AdMob**
- Create AdMob account
- Use provided app ID: ca-app-pub-2816879682508424~6111146883
- Implement ad units in appropriate sections

6. **Create Admin User**
```javascript
// In Firebase Console, go to Authentication
// Create a user, then in Realtime Database:
{
  "users": {
    "USER_UID_HERE": {
      "isAdmin": true,
      "username": "admin",
      "email": "admin@z1job.com"
    }
  }
}
```

## 🚀 Running the Application

1. **Development Mode**
```bash
npm run dev
```

2. **Build for Production**
```bash
npm run build
```

3. **Preview Production Build**
```bash
npm run preview
```

## 📊 Database Schema

### Users Collection
```javascript
{
  "users": {
    "userId": {
      "username": "string",
      "email": "string",
      "password_hash": "string",
      "isAdmin": "boolean",
      "isAdvertiser": "boolean",
      "planId": "number",
      "balance": "number",
      "fraudScore": "number",
      "country": "string",
      "currency": "string",
      "createdAt": "ISO timestamp",
      "updatedAt": "ISO timestamp"
    }
  }
}
```

### Plans Configuration (In-Memory)
- Free Plan: Rs 0, 5 daily tasks
- Silver: Rs 500, 20 daily tasks
- Gold: Rs 1,500, 50 daily tasks (Most Popular)
- Platinum: Rs 3,000, 100 daily tasks (VIP)
- Diamond Elite: Rs 7,000, 200 daily tasks (VIP)
- Lifetime Exclusive: Rs 25,000, 500 daily tasks (Featured)

### Tasks Collection
```javascript
{
  "tasks": {
    "taskId": {
      "userId": "string",
      "taskType": "string",
      "reward": "number",
      "completedAt": "ISO timestamp",
      "status": "completed|pending|failed"
    }
  }
}
```

### Withdrawals Collection
```javascript
{
  "withdrawals": {
    "withdrawalId": {
      "userId": "string",
      "amount": "number",
      "method": "JazzCash|Easypaisa|Bank|Paiker",
      "accountInfo": "string",
      "status": "pending|completed|rejected",
      "requestDate": "ISO timestamp",
      "processedDate": "ISO timestamp",
      "remarks": "string"
    }
  }
}
```

### Campaigns Collection
```javascript
{
  "campaigns": {
    "campaignId": {
      "advertiserId": "string",
      "name": "string",
      "budget": "number",
      "spent": "number",
      "tasksMax": "number",
      "tasksCompleted": "number",
      "duration": "number",
      "status": "active|paused|completed",
      "fraudLevel": "standard|strict"
    }
  }
}
```

## 🔒 Security Implementation

### 1. Password Encryption
```javascript
// Server-side implementation needed
const bcrypt = require('bcrypt');
const saltRounds = 10;
const hashedPassword = await bcrypt.hash(password, saltRounds);
```

### 2. Fraud Detection
```javascript
const calculateFraudScore = (user, action) => {
  let score = 0;
  if (action.rapidActions) score += 30;
  if (action.vpnDetected) score += 40;
  if (action.multipleAccounts) score += 50;
  if (action.botBehavior) score += 60;
  
  // Auto suspend if score > 50
  if (score > 50) {
    suspendUser(user.id);
  }
  
  return score;
};
```

### 3. Payment Security
- All payment API keys stored server-side
- Use environment variables for sensitive data
- Implement HTTPS for all transactions
- Validate amounts and limits before processing

## 💳 Payment Integration

### Paiker Implementation
```javascript
const createPayment = async (amount, currency, customer) => {
  const response = await fetch('https://paiker.site/v1/payment_intents', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env.PAIKER_SECRET_KEY}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      amount: amount * 100, // Convert to smallest currency unit
      currency: currency,
      customer: customer
    })
  });
  
  return await response.json();
};
```

### Test Cards (Development)
- Success: 4242 4242 4242 4242
- Declined: 4000 0000 0000 0002

## 🌍 Multi-Currency Support

```javascript
const CURRENCIES = {
  PK: { code: 'PKR', symbol: 'Rs', conversionRate: 1 },
  US: { code: 'USD', symbol: '$', conversionRate: 0.0036 },
  IN: { code: 'INR', symbol: '₹', conversionRate: 0.30 },
  GB: { code: 'GBP', symbol: '£', conversionRate: 0.0028 }
};

const convertCurrency = (amount, fromCurrency, toCurrency) => {
  const baseAmount = amount / CURRENCIES[fromCurrency].conversionRate;
  return baseAmount * CURRENCIES[toCurrency].conversionRate;
};
```

## 📱 AdMob Integration

```html
<!-- Add to index.html -->
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-app-pub-2816879682508424~6111146883" crossorigin="anonymous"></script>

<!-- Ad Unit Implementation -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-app-pub-2816879682508424~6111146883"
     data-ad-slot="9931403595"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
```

## 🎯 Features to Implement

### Phase 1 (Current)
- ✅ Basic authentication
- ✅ User dashboard
- ✅ Task system
- ✅ Plan management
- ✅ Admin panel
- ✅ Advertiser dashboard

### Phase 2 (Recommended)
- 🔄 Server-side API for security
- 🔄 Advanced fraud detection ML model
- 🔄 Real-time notifications
- 🔄 Email verification
- 🔄 Two-factor authentication
- 🔄 Advanced analytics

### Phase 3 (Future)
- 🔄 Mobile app (React Native)
- 🔄 White-label solution for resellers
- 🔄 API for third-party integration
- 🔄 Advanced reporting and exports
- 🔄 Referral system
- 🔄 Gamification features

## 🛠️ Customization

### Changing Colors
```css
:root {
  --bg-dark: #0D0D0D;
  --bg-card: #1A1A1A;
  --gold-primary: #C9A227;
  --gold-secondary: #FFD700;
  --text-light: #FFFFFF;
  --text-gray: #B0B0B0;
}
```

### Adding New Plans
```javascript
const NEW_PLAN = {
  id: 7,
  name: 'Enterprise',
  price: 50000,
  duration: 365,
  dailyTaskLimit: 1000,
  dailyEarningLimit: 50000,
  withdrawLimit: 200000,
  taskReward: 100,
  fraudStrictness: 'minimal',
  adsPercentage: 0,
  perks: 'Dedicated support',
  badge: 'Enterprise'
};
```

## 📈 Scaling Considerations

1. **Database**: Migrate to Firebase Firestore for better scalability
2. **Server**: Implement Node.js/Express backend for sensitive operations
3. **CDN**: Use CloudFlare or AWS CloudFront for static assets
4. **Caching**: Implement Redis for frequently accessed data
5. **Load Balancing**: Use AWS ELB or Google Cloud Load Balancer
6. **Monitoring**: Implement Sentry for error tracking

## 🐛 Troubleshooting

### Firebase Connection Issues
- Check Firebase configuration
- Verify API keys are correct
- Ensure Firebase services are enabled

### Payment Failures
- Verify Paiker API keys
- Check test card numbers
- Ensure proper error handling

### Slow Performance
- Implement lazy loading
- Use React.memo for components
- Optimize database queries
- Add loading states

## 📄 License

This is a proprietary platform. All rights reserved.

## 👥 Support

For support, email: support@z1job.com

## 🚀 Deployment

### Vercel Deployment
```bash
npm install -g vercel
vercel
```

### Netlify Deployment
```bash
npm run build
# Upload dist folder to Netlify
```

### Firebase Hosting
```bash
npm install -g firebase-tools
firebase init hosting
firebase deploy
```

## 🔐 Environment Variables

Create `.env` file:
```env
VITE_FIREBASE_API_KEY=your_api_key
VITE_FIREBASE_AUTH_DOMAIN=your_auth_domain
VITE_FIREBASE_DATABASE_URL=your_database_url
VITE_FIREBASE_PROJECT_ID=your_project_id
VITE_FIREBASE_STORAGE_BUCKET=your_storage_bucket
VITE_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
VITE_FIREBASE_APP_ID=your_app_id
VITE_PAIKER_PUBLISHABLE_KEY=your_paiker_key
```

## 📞 Contact

- Website: https://z1job.com
- Email: info@z1job.com
- Support: support@z1job.com

---

**Built with ❤️ for the Z1 JOB Platform**
