# FIREBASE SECURITY RULES CONFIGURATION

## Realtime Database Rules

Copy and paste these rules into your Firebase Console → Realtime Database → Rules

```json
{
  "rules": {
    "users": {
      "$uid": {
        ".read": "$uid === auth.uid || root.child('users').child(auth.uid).child('isAdmin').val() === true",
        ".write": "$uid === auth.uid || root.child('users').child(auth.uid).child('isAdmin').val() === true",
        ".validate": "newData.hasChildren(['username', 'email', 'planId', 'balance', 'country', 'currency'])",
        "username": {
          ".validate": "newData.isString() && newData.val().length > 2 && newData.val().length < 50"
        },
        "email": {
          ".validate": "newData.isString() && newData.val().matches(/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}$/i)"
        },
        "balance": {
          ".validate": "newData.isNumber() && newData.val() >= 0"
        },
        "fraudScore": {
          ".validate": "newData.isNumber() && newData.val() >= 0 && newData.val() <= 100"
        },
        "isAdmin": {
          ".write": "root.child('users').child(auth.uid).child('isAdmin').val() === true"
        }
      }
    },
    
    "tasks": {
      ".read": "auth != null",
      "$taskId": {
        ".write": "auth != null && (!data.exists() || data.child('userId').val() === auth.uid || root.child('users').child(auth.uid).child('isAdmin').val() === true)",
        ".validate": "newData.hasChildren(['userId', 'taskType', 'reward', 'status'])",
        "userId": {
          ".validate": "newData.val() === auth.uid"
        },
        "reward": {
          ".validate": "newData.isNumber() && newData.val() > 0"
        },
        "status": {
          ".validate": "newData.isString() && (newData.val() === 'completed' || newData.val() === 'pending' || newData.val() === 'failed')"
        }
      }
    },
    
    "withdrawals": {
      ".read": "auth != null",
      "$withdrawalId": {
        ".write": "auth != null && (!data.exists() || root.child('users').child(auth.uid).child('isAdmin').val() === true)",
        ".validate": "newData.hasChildren(['userId', 'amount', 'method', 'status'])",
        "userId": {
          ".validate": "newData.val() === auth.uid || root.child('users').child(auth.uid).child('isAdmin').val() === true"
        },
        "amount": {
          ".validate": "newData.isNumber() && newData.val() >= 100"
        },
        "status": {
          ".validate": "newData.isString() && (newData.val() === 'pending' || newData.val() === 'completed' || newData.val() === 'rejected')"
        }
      }
    },
    
    "campaigns": {
      ".read": "auth != null",
      "$campaignId": {
        ".write": "auth != null && (!data.exists() || data.child('advertiserId').val() === auth.uid || root.child('users').child(auth.uid).child('isAdmin').val() === true)",
        ".validate": "newData.hasChildren(['advertiserId', 'name', 'budget', 'status'])",
        "advertiserId": {
          ".validate": "newData.val() === auth.uid || root.child('users').child(auth.uid).child('isAdmin').val() === true"
        },
        "budget": {
          ".validate": "newData.isNumber() && newData.val() > 0"
        }
      }
    },
    
    "login_logs": {
      ".read": "root.child('users').child(auth.uid).child('isAdmin').val() === true",
      "$logId": {
        ".write": "auth != null",
        ".validate": "newData.hasChildren(['userId', 'ip_address', 'login_time'])"
      }
    },
    
    "wallet": {
      ".read": "auth != null",
      "$walletId": {
        ".write": "root.child('users').child(auth.uid).child('isAdmin').val() === true",
        ".validate": "newData.hasChildren(['userId', 'change_amount', 'new_balance', 'type'])"
      }
    }
  }
}
```

## Firestore Rules (Alternative to Realtime Database)

If you prefer Firestore, use these rules:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Users collection
    match /users/{userId} {
      allow read: if request.auth != null && 
        (request.auth.uid == userId || 
         get(/databases/$(database)/documents/users/$(request.auth.uid)).data.isAdmin == true);
      
      allow create: if request.auth != null && request.auth.uid == userId;
      
      allow update: if request.auth != null && 
        (request.auth.uid == userId || 
         get(/databases/$(database)/documents/users/$(request.auth.uid)).data.isAdmin == true);
      
      allow delete: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.isAdmin == true;
    }
    
    // Tasks collection
    match /tasks/{taskId} {
      allow read: if request.auth != null;
      
      allow create: if request.auth != null && 
        request.resource.data.userId == request.auth.uid;
      
      allow update, delete: if request.auth != null && 
        (resource.data.userId == request.auth.uid || 
         get(/databases/$(database)/documents/users/$(request.auth.uid)).data.isAdmin == true);
    }
    
    // Withdrawals collection
    match /withdrawals/{withdrawalId} {
      allow read: if request.auth != null;
      
      allow create: if request.auth != null && 
        request.resource.data.userId == request.auth.uid &&
        request.resource.data.amount >= 100;
      
      allow update: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.isAdmin == true;
    }
    
    // Campaigns collection
    match /campaigns/{campaignId} {
      allow read: if request.auth != null;
      
      allow create: if request.auth != null && 
        request.resource.data.advertiserId == request.auth.uid;
      
      allow update, delete: if request.auth != null && 
        (resource.data.advertiserId == request.auth.uid || 
         get(/databases/$(database)/documents/users/$(request.auth.uid)).data.isAdmin == true);
    }
  }
}
```

## Storage Rules (For User Uploads)

```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /users/{userId}/{allPaths=**} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
    
    match /public/{allPaths=**} {
      allow read: if true;
      allow write: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.isAdmin == true;
    }
  }
}
```

## Firebase Authentication Configuration

1. **Enable Email/Password Authentication**
   - Go to Firebase Console → Authentication → Sign-in method
   - Enable "Email/Password"

2. **Configure Password Requirements**
   - Minimum 8 characters
   - Require strong passwords (handled client-side)

3. **Enable Email Verification** (Optional but recommended)
   ```javascript
   import { sendEmailVerification } from 'firebase/auth';
   
   await sendEmailVerification(user);
   ```

4. **Set up Password Reset**
   ```javascript
   import { sendPasswordResetEmail } from 'firebase/auth';
   
   await sendPasswordResetEmail(auth, email);
   ```

## Admin User Setup

To create an admin user, manually add the user in Firebase Console:

1. Go to Authentication → Users → Add User
2. Create the user with email and password
3. Note the User UID
4. Go to Realtime Database → Data
5. Create/update the user record:

```json
{
  "users": {
    "USER_UID_HERE": {
      "username": "admin",
      "email": "admin@z1job.com",
      "isAdmin": true,
      "isAdvertiser": false,
      "planId": 6,
      "balance": 0,
      "fraudScore": 0,
      "country": "PK",
      "currency": "PKR",
      "createdAt": "2026-02-13T00:00:00.000Z",
      "updatedAt": "2026-02-13T00:00:00.000Z"
    }
  }
}
```

## Database Indexes (for better performance)

If using Realtime Database, indexes are handled automatically.

For Firestore, create these indexes:

1. Tasks collection:
   - userId (ascending), completedAt (descending)
   - status (ascending), completedAt (descending)

2. Withdrawals collection:
   - userId (ascending), requestDate (descending)
   - status (ascending), requestDate (descending)

3. Campaigns collection:
   - advertiserId (ascending), status (ascending)

## Rate Limiting

Implement rate limiting for sensitive operations:

```javascript
// In Firebase Functions
const functions = require('firebase-functions');
const admin = require('firebase-admin');

exports.rateLimit = functions.https.onCall(async (data, context) => {
  const uid = context.auth.uid;
  const action = data.action;
  
  // Check rate limit
  const rateLimitRef = admin.database().ref(`rateLimit/${uid}/${action}`);
  const snapshot = await rateLimitRef.once('value');
  const count = snapshot.val() || 0;
  
  if (count > 10) { // 10 requests per minute
    throw new functions.https.HttpsError('resource-exhausted', 'Rate limit exceeded');
  }
  
  await rateLimitRef.set(count + 1);
  setTimeout(() => rateLimitRef.set(0), 60000); // Reset after 1 minute
  
  return { success: true };
});
```

## Backup Strategy

Set up automated backups:

1. **Realtime Database**
   - Enable automated backups in Firebase Console
   - Schedule: Daily at 2 AM UTC

2. **Firestore**
   - Use Firebase CLI to schedule backups
   ```bash
   firebase deploy --only firestore:backup
   ```

3. **Authentication**
   - Export user data regularly
   - Store securely with encryption

## Security Best Practices

1. ✅ Never expose Firebase config in public repos
2. ✅ Use environment variables for sensitive data
3. ✅ Implement server-side validation
4. ✅ Enable App Check for additional security
5. ✅ Monitor security rules usage
6. ✅ Regularly audit user permissions
7. ✅ Implement IP whitelisting for admin panel
8. ✅ Use Firebase Security Rules simulator for testing
9. ✅ Enable 2FA for admin accounts
10. ✅ Regularly update Firebase SDK versions
