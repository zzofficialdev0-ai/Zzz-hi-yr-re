import React, { useState, useEffect } from 'react';
import { initializeApp } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, onAuthStateChanged, signOut } from 'firebase/auth';
import { getDatabase, ref, set, get, update, push, onValue, query, orderByChild, equalTo } from 'firebase/database';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

// Firebase Configuration
const firebaseConfig = {
  apiKey: "AIzaSyABzs1RdCMtf3K92ybOQ2TvhEU9fNeoqbM",
  authDomain: "mysutecomcom.firebaseapp.com",
  databaseURL: "https://mysutecomcom-default-rtdb.firebaseio.com",
  projectId: "mysutecomcom",
  storageBucket: "mysutecomcom.firebasestorage.app",
  messagingSenderId: "251111602946",
  appId: "1:251111602946:web:734311f5638abc8c62201b",
  measurementId: "G-Z0FV21ME5G"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const database = getDatabase(app);

// Payment Configuration
const PAIKER_CONFIG = {
  publishableKey: 'pk_test_27c708dd81369778ea0e56637fc1d6aa0f6302c09b35a535',
  secretKey: 'sk_test_4e7f...82d75156', // Should be server-side only
  apiUrl: 'https://paiker.site/v1'
};

// Plans Configuration
const USER_PLANS = [
  { id: 1, name: 'Free', price: 0, duration: 30, dailyTaskLimit: 5, dailyEarningLimit: 50, withdrawLimit: 100, taskReward: 2, fraudStrictness: 'high', adsPercentage: 100, perks: 'Basic access', badge: null },
  { id: 2, name: 'Silver', price: 500, duration: 30, dailyTaskLimit: 20, dailyEarningLimit: 200, withdrawLimit: 500, taskReward: 5, fraudStrictness: 'medium', adsPercentage: 50, perks: 'Priority tasks', badge: null },
  { id: 3, name: 'Gold', price: 1500, duration: 30, dailyTaskLimit: 50, dailyEarningLimit: 500, withdrawLimit: 2000, taskReward: 10, fraudStrictness: 'medium', adsPercentage: 30, perks: 'Fast withdrawals', badge: 'Most Popular' },
  { id: 4, name: 'Platinum', price: 3000, duration: 30, dailyTaskLimit: 100, dailyEarningLimit: 1500, withdrawLimit: 5000, taskReward: 15, fraudStrictness: 'low', adsPercentage: 10, perks: 'Instant withdraw', badge: 'VIP' },
  { id: 5, name: 'Diamond Elite', price: 7000, duration: 30, dailyTaskLimit: 200, dailyEarningLimit: 3000, withdrawLimit: 15000, taskReward: 25, fraudStrictness: 'minimal', adsPercentage: 0, perks: 'Premium support', badge: 'VIP' },
  { id: 6, name: 'Lifetime Exclusive', price: 25000, duration: 36500, dailyTaskLimit: 500, dailyEarningLimit: 10000, withdrawLimit: 50000, taskReward: 50, fraudStrictness: 'minimal', adsPercentage: 0, perks: 'All features forever', badge: 'Featured' }
];

const COMPANION_PLANS = Array.from({ length: 20 }, (_, i) => ({
  id: i + 1,
  name: `Advertiser ${i + 1}`,
  price: 500 + (i * 3500),
  maxTasks: (i + 1) * 100,
  minTaskPrice: 5,
  duration: 30,
  countryTargeting: ['PK', 'IN', 'BD', 'US'],
  fraudLevel: i < 10 ? 'standard' : 'strict',
  vipBadge: i >= 15
}));

const TASK_TYPES = ['Social Follow', 'Like', 'Share', 'Website Visit', 'App Download'];

// Utility Functions
const detectCountry = () => {
  // In production, use IP geolocation API
  return { country: 'PK', currency: 'PKR', language: 'en' };
};

const getCurrencySymbol = (currency) => {
  const symbols = { PKR: 'Rs', USD: '$', INR: '₹', EUR: '€', GBP: '£' };
  return symbols[currency] || currency;
};

const encryptPassword = async (password) => {
  // Simplified - in production use bcrypt on server
  return btoa(password);
};

const calculateFraudScore = (user, action) => {
  let score = 0;
  // Simple fraud detection logic
  if (action.rapidActions) score += 30;
  if (action.vpnDetected) score += 40;
  if (action.multipleAccounts) score += 50;
  return score;
};

// Main App Component
export default function Z1JobPlatform() {
  const [currentUser, setCurrentUser] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [view, setView] = useState('landing'); // landing, signup, login, dashboard, admin, advertiser
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        setCurrentUser(user);
        const userRef = ref(database, `users/${user.uid}`);
        const snapshot = await get(userRef);
        if (snapshot.exists()) {
          const data = snapshot.val();
          setUserData(data);
          setIsAdmin(data.isAdmin || false);
          setView(data.isAdmin ? 'admin' : data.isAdvertiser ? 'advertiser' : 'dashboard');
        }
      } else {
        setCurrentUser(null);
        setUserData(null);
        setIsAdmin(false);
        setView('landing');
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  if (loading) {
    return <LoadingScreen />;
  }

  return (
    <div className="app-container">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@700;800&family=Inter:wght@400;500;600&display=swap');
        
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }
        
        :root {
          --bg-dark: #0D0D0D;
          --bg-card: #1A1A1A;
          --gold-primary: #C9A227;
          --gold-secondary: #FFD700;
          --text-light: #FFFFFF;
          --text-gray: #B0B0B0;
          --success: #10B981;
          --danger: #EF4444;
          --warning: #F59E0B;
        }
        
        body {
          font-family: 'Inter', sans-serif;
          background: var(--bg-dark);
          color: var(--text-light);
          overflow-x: hidden;
        }
        
        .app-container {
          min-height: 100vh;
          background: linear-gradient(135deg, #0D0D0D 0%, #1A1A1A 100%);
        }
        
        /* Animations */
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes pulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.05); }
        }
        
        @keyframes glow {
          0%, 100% { box-shadow: 0 0 20px rgba(201, 162, 39, 0.3); }
          50% { box-shadow: 0 0 40px rgba(255, 215, 0, 0.6); }
        }
        
        @keyframes ripple {
          0% { transform: scale(0); opacity: 1; }
          100% { transform: scale(4); opacity: 0; }
        }
        
        @keyframes letterGlow {
          0% { text-shadow: 0 0 5px rgba(201, 162, 39, 0.5); }
          50% { text-shadow: 0 0 20px rgba(255, 215, 0, 0.8), 0 0 30px rgba(255, 215, 0, 0.6); }
          100% { text-shadow: 0 0 5px rgba(201, 162, 39, 0.5); }
        }
        
        /* Navigation */
        .navbar {
          background: rgba(26, 26, 26, 0.95);
          backdrop-filter: blur(10px);
          padding: 1.5rem 5%;
          position: sticky;
          top: 0;
          z-index: 1000;
          display: flex;
          justify-content: space-between;
          align-items: center;
          border-bottom: 2px solid rgba(201, 162, 39, 0.2);
        }
        
        .logo {
          font-family: 'Poppins', sans-serif;
          font-size: 2rem;
          font-weight: 800;
          background: linear-gradient(135deg, var(--gold-primary), var(--gold-secondary));
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          animation: letterGlow 3s infinite;
          cursor: pointer;
        }
        
        .nav-buttons {
          display: flex;
          gap: 1rem;
        }
        
        /* Buttons */
        .btn {
          padding: 0.75rem 2rem;
          border: none;
          border-radius: 50px;
          font-family: 'Inter', sans-serif;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s ease;
          position: relative;
          overflow: hidden;
        }
        
        .btn-primary {
          background: linear-gradient(135deg, var(--gold-primary), var(--gold-secondary));
          color: var(--bg-dark);
          animation: glow 2s infinite;
        }
        
        .btn-primary:hover {
          animation: pulse 0.5s ease-in-out, glow 2s infinite;
        }
        
        .btn-secondary {
          background: transparent;
          color: var(--gold-primary);
          border: 2px solid var(--gold-primary);
        }
        
        .btn-secondary:hover {
          background: rgba(201, 162, 39, 0.1);
        }
        
        .btn::after {
          content: '';
          position: absolute;
          top: 50%;
          left: 50%;
          width: 0;
          height: 0;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.3);
          transform: translate(-50%, -50%);
          transition: width 0.6s, height 0.6s;
        }
        
        .btn:active::after {
          width: 300px;
          height: 300px;
          animation: ripple 0.6s;
        }
        
        /* Cards */
        .card {
          background: var(--bg-card);
          border-radius: 20px;
          padding: 2rem;
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3), 0 0 20px rgba(201, 162, 39, 0.1);
          transition: all 0.3s ease;
          animation: fadeIn 0.6s ease-out;
          border: 1px solid rgba(201, 162, 39, 0.2);
        }
        
        .card:hover {
          transform: translateY(-10px);
          box-shadow: 0 12px 48px rgba(0, 0, 0, 0.4), 0 0 40px rgba(255, 215, 0, 0.3);
        }
        
        /* Hero Section */
        .hero {
          text-align: center;
          padding: 8rem 5% 5rem;
          background: radial-gradient(circle at center, rgba(201, 162, 39, 0.1) 0%, transparent 70%);
        }
        
        .hero h1 {
          font-family: 'Poppins', sans-serif;
          font-size: 4.5rem;
          font-weight: 800;
          background: linear-gradient(135deg, var(--gold-primary), var(--gold-secondary));
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          margin-bottom: 1.5rem;
          animation: letterGlow 3s infinite;
        }
        
        .hero p {
          font-size: 1.3rem;
          color: var(--text-gray);
          margin-bottom: 3rem;
          max-width: 700px;
          margin-left: auto;
          margin-right: auto;
        }
        
        /* Form Styles */
        .form-container {
          max-width: 500px;
          margin: 3rem auto;
          padding: 0 1rem;
        }
        
        .input-group {
          margin-bottom: 1.5rem;
        }
        
        .input-group label {
          display: block;
          margin-bottom: 0.5rem;
          color: var(--gold-primary);
          font-weight: 600;
        }
        
        .input-group input, .input-group select {
          width: 100%;
          padding: 1rem;
          border: 2px solid rgba(201, 162, 39, 0.3);
          border-radius: 12px;
          background: var(--bg-card);
          color: var(--text-light);
          font-family: 'Inter', sans-serif;
          transition: all 0.3s ease;
        }
        
        .input-group input:focus, .input-group select:focus {
          outline: none;
          border-color: var(--gold-secondary);
          box-shadow: 0 0 20px rgba(255, 215, 0, 0.3);
        }
        
        /* Plans Grid */
        .plans-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 2rem;
          padding: 3rem 5%;
        }
        
        .plan-card {
          position: relative;
          padding: 2.5rem;
        }
        
        .plan-badge {
          position: absolute;
          top: -15px;
          right: 20px;
          padding: 0.5rem 1.5rem;
          background: linear-gradient(135deg, var(--gold-primary), var(--gold-secondary));
          color: var(--bg-dark);
          font-weight: 700;
          border-radius: 20px;
          font-size: 0.85rem;
        }
        
        .plan-name {
          font-family: 'Poppins', sans-serif;
          font-size: 2rem;
          font-weight: 700;
          color: var(--gold-secondary);
          margin-bottom: 1rem;
        }
        
        .plan-price {
          font-size: 3rem;
          font-weight: 800;
          color: var(--text-light);
          margin-bottom: 2rem;
        }
        
        .plan-price span {
          font-size: 1.2rem;
          color: var(--text-gray);
        }
        
        .plan-features {
          list-style: none;
          margin-bottom: 2rem;
        }
        
        .plan-features li {
          padding: 0.75rem 0;
          border-bottom: 1px solid rgba(201, 162, 39, 0.1);
          display: flex;
          justify-content: space-between;
        }
        
        /* Dashboard */
        .dashboard {
          padding: 3rem 5%;
        }
        
        .stats-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 2rem;
          margin-bottom: 3rem;
        }
        
        .stat-card {
          text-align: center;
          padding: 2rem;
        }
        
        .stat-value {
          font-size: 3rem;
          font-weight: 800;
          background: linear-gradient(135deg, var(--gold-primary), var(--gold-secondary));
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          margin-bottom: 0.5rem;
        }
        
        .stat-label {
          color: var(--text-gray);
          font-size: 1rem;
        }
        
        /* Task Board */
        .task-board {
          margin-top: 3rem;
        }
        
        .task-item {
          background: var(--bg-card);
          padding: 1.5rem;
          border-radius: 12px;
          margin-bottom: 1rem;
          display: flex;
          justify-content: space-between;
          align-items: center;
          border: 1px solid rgba(201, 162, 39, 0.2);
          transition: all 0.3s ease;
        }
        
        .task-item:hover {
          border-color: var(--gold-secondary);
          transform: translateX(5px);
        }
        
        .task-info h4 {
          color: var(--gold-secondary);
          margin-bottom: 0.5rem;
        }
        
        .task-reward {
          font-size: 1.5rem;
          font-weight: 700;
          color: var(--success);
        }
        
        /* Admin Panel */
        .admin-panel {
          padding: 3rem 5%;
        }
        
        .admin-tabs {
          display: flex;
          gap: 1rem;
          margin-bottom: 3rem;
          border-bottom: 2px solid rgba(201, 162, 39, 0.2);
          padding-bottom: 1rem;
        }
        
        .admin-tab {
          padding: 1rem 2rem;
          background: transparent;
          border: none;
          color: var(--text-gray);
          cursor: pointer;
          font-weight: 600;
          transition: all 0.3s ease;
        }
        
        .admin-tab.active {
          color: var(--gold-secondary);
          border-bottom: 3px solid var(--gold-secondary);
        }
        
        .table-container {
          overflow-x: auto;
          background: var(--bg-card);
          border-radius: 12px;
          padding: 1.5rem;
        }
        
        table {
          width: 100%;
          border-collapse: collapse;
        }
        
        th, td {
          padding: 1rem;
          text-align: left;
          border-bottom: 1px solid rgba(201, 162, 39, 0.1);
        }
        
        th {
          color: var(--gold-secondary);
          font-weight: 700;
        }
        
        /* Loading Screen */
        .loading-screen {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          height: 100vh;
          background: var(--bg-dark);
        }
        
        .spinner {
          width: 80px;
          height: 80px;
          border: 8px solid rgba(201, 162, 39, 0.2);
          border-top: 8px solid var(--gold-secondary);
          border-radius: 50%;
          animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        
        /* Responsive */
        @media (max-width: 768px) {
          .hero h1 { font-size: 2.5rem; }
          .plans-grid { grid-template-columns: 1fr; }
          .stats-grid { grid-template-columns: 1fr; }
          .navbar { flex-direction: column; gap: 1rem; }
        }
        
        /* Badge Animations */
        .badge {
          display: inline-block;
          padding: 0.3rem 0.8rem;
          border-radius: 20px;
          font-size: 0.75rem;
          font-weight: 700;
          text-transform: uppercase;
        }
        
        .badge-vip {
          background: linear-gradient(135deg, #FFD700, #FFA500);
          color: var(--bg-dark);
          animation: pulse 2s infinite;
        }
        
        .badge-featured {
          background: linear-gradient(135deg, #C9A227, #8B6914);
          color: white;
        }
        
        .badge-popular {
          background: linear-gradient(135deg, #10B981, #059669);
          color: white;
        }
      `}</style>

      {view === 'landing' && <LandingPage setView={setView} />}
      {view === 'signup' && <SignupPage setView={setView} />}
      {view === 'login' && <LoginPage setView={setView} />}
      {view === 'dashboard' && <UserDashboard user={currentUser} userData={userData} setView={setView} />}
      {view === 'admin' && <AdminPanel setView={setView} />}
      {view === 'advertiser' && <AdvertiserDashboard user={currentUser} userData={userData} setView={setView} />}
    </div>
  );
}

// Loading Screen Component
function LoadingScreen() {
  return (
    <div className="loading-screen">
      <div className="spinner"></div>
      <h2 style={{ marginTop: '2rem', color: '#FFD700' }}>Loading Z1 JOB...</h2>
    </div>
  );
}

// Landing Page Component
function LandingPage({ setView }) {
  return (
    <>
      <nav className="navbar">
        <div className="logo">Z1 JOB</div>
        <div className="nav-buttons">
          <button className="btn btn-secondary" onClick={() => setView('login')}>Login</button>
          <button className="btn btn-primary" onClick={() => setView('signup')}>Get Started</button>
        </div>
      </nav>
      
      <section className="hero">
        <h1>Earn Money Online</h1>
        <p>Complete simple tasks, earn real money. Join thousands of users already making income with Z1 JOB - the premium earning platform.</p>
        <button className="btn btn-primary" onClick={() => setView('signup')} style={{ fontSize: '1.2rem', padding: '1rem 3rem' }}>
          Start Earning Now →
        </button>
      </section>
      
      <section style={{ padding: '3rem 5%' }}>
        <h2 style={{ textAlign: 'center', fontSize: '2.5rem', marginBottom: '3rem', color: '#FFD700' }}>Choose Your Plan</h2>
        <div className="plans-grid">
          {USER_PLANS.map((plan, index) => (
            <div className="card plan-card" key={plan.id} style={{ animationDelay: `${index * 0.1}s` }}>
              {plan.badge && <div className={`plan-badge ${plan.badge === 'VIP' ? 'badge-vip' : plan.badge === 'Featured' ? 'badge-featured' : 'badge-popular'}`}>{plan.badge}</div>}
              <div className="plan-name">{plan.name}</div>
              <div className="plan-price">
                Rs {plan.price.toLocaleString()}
                <span> /{plan.duration} days</span>
              </div>
              <ul className="plan-features">
                <li><span>Daily Tasks</span><strong>{plan.dailyTaskLimit}</strong></li>
                <li><span>Daily Earning</span><strong>Rs {plan.dailyEarningLimit}</strong></li>
                <li><span>Withdraw Limit</span><strong>Rs {plan.withdrawLimit}</strong></li>
                <li><span>Per Task</span><strong>Rs {plan.taskReward}</strong></li>
                <li><span>Ads</span><strong>{plan.adsPercentage}%</strong></li>
              </ul>
              <button className="btn btn-primary" style={{ width: '100%' }} onClick={() => setView('signup')}>
                Select Plan
              </button>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}

// Signup Page Component
function SignupPage({ setView }) {
  const [formData, setFormData] = useState({
    username: '', email: '', password: '', confirmPassword: '', plan: 1
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSignup = async (e) => {
    e.preventDefault();
    setError('');
    
    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      return;
    }
    
    if (formData.password.length < 8) {
      setError('Password must be at least 8 characters');
      return;
    }
    
    setLoading(true);
    
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, formData.email, formData.password);
      const user = userCredential.user;
      
      const countryData = detectCountry();
      
      const userRef = ref(database, `users/${user.uid}`);
      await set(userRef, {
        username: formData.username,
        email: formData.email,
        planId: formData.plan,
        balance: 0,
        fraudScore: 0,
        country: countryData.country,
        currency: countryData.currency,
        isAdmin: false,
        isAdvertiser: false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
      
      setView('dashboard');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <nav className="navbar">
        <div className="logo" onClick={() => setView('landing')}>Z1 JOB</div>
      </nav>
      
      <div className="form-container">
        <div className="card">
          <h2 style={{ textAlign: 'center', color: '#FFD700', marginBottom: '2rem', fontSize: '2rem' }}>Create Account</h2>
          
          {error && <div style={{ padding: '1rem', background: 'rgba(239, 68, 68, 0.2)', borderRadius: '8px', marginBottom: '1rem', color: '#EF4444' }}>{error}</div>}
          
          <form onSubmit={handleSignup}>
            <div className="input-group">
              <label>Username</label>
              <input type="text" required value={formData.username} onChange={(e) => setFormData({...formData, username: e.target.value})} />
            </div>
            
            <div className="input-group">
              <label>Email</label>
              <input type="email" required value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})} />
            </div>
            
            <div className="input-group">
              <label>Password (min 8 characters)</label>
              <input type="password" required value={formData.password} onChange={(e) => setFormData({...formData, password: e.target.value})} />
            </div>
            
            <div className="input-group">
              <label>Confirm Password</label>
              <input type="password" required value={formData.confirmPassword} onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})} />
            </div>
            
            <div className="input-group">
              <label>Select Plan</label>
              <select value={formData.plan} onChange={(e) => setFormData({...formData, plan: parseInt(e.target.value)})}>
                {USER_PLANS.map(plan => (
                  <option key={plan.id} value={plan.id}>{plan.name} - Rs {plan.price}</option>
                ))}
              </select>
            </div>
            
            <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '1rem' }} disabled={loading}>
              {loading ? 'Creating Account...' : 'Sign Up'}
            </button>
          </form>
          
          <p style={{ textAlign: 'center', marginTop: '1.5rem', color: '#B0B0B0' }}>
            Already have an account? <span style={{ color: '#FFD700', cursor: 'pointer' }} onClick={() => setView('login')}>Login</span>
          </p>
        </div>
      </div>
    </>
  );
}

// Login Page Component
function LoginPage({ setView }) {
  const [formData, setFormData] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    
    try {
      await signInWithEmailAndPassword(auth, formData.email, formData.password);
      // View will be set automatically by onAuthStateChanged
    } catch (err) {
      setError('Invalid email or password');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <nav className="navbar">
        <div className="logo" onClick={() => setView('landing')}>Z1 JOB</div>
      </nav>
      
      <div className="form-container">
        <div className="card">
          <h2 style={{ textAlign: 'center', color: '#FFD700', marginBottom: '2rem', fontSize: '2rem' }}>Welcome Back</h2>
          
          {error && <div style={{ padding: '1rem', background: 'rgba(239, 68, 68, 0.2)', borderRadius: '8px', marginBottom: '1rem', color: '#EF4444' }}>{error}</div>}
          
          <form onSubmit={handleLogin}>
            <div className="input-group">
              <label>Email</label>
              <input type="email" required value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})} />
            </div>
            
            <div className="input-group">
              <label>Password</label>
              <input type="password" required value={formData.password} onChange={(e) => setFormData({...formData, password: e.target.value})} />
            </div>
            
            <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '1rem' }} disabled={loading}>
              {loading ? 'Logging in...' : 'Login'}
            </button>
          </form>
          
          <p style={{ textAlign: 'center', marginTop: '1.5rem', color: '#B0B0B0' }}>
            Don't have an account? <span style={{ color: '#FFD700', cursor: 'pointer' }} onClick={() => setView('signup')}>Sign Up</span>
          </p>
        </div>
      </div>
    </>
  );
}

// User Dashboard Component
function UserDashboard({ user, userData, setView }) {
  const [tasks, setTasks] = useState([]);
  const [stats, setStats] = useState({ todayEarnings: 0, tasksCompleted: 0, balance: userData?.balance || 0 });
  const [withdrawals, setWithdrawals] = useState([]);
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);

  useEffect(() => {
    loadTasks();
    loadStats();
    loadWithdrawals();
  }, [user]);

  const loadTasks = async () => {
    const mockTasks = TASK_TYPES.map((type, index) => ({
      id: `task_${index}`,
      type,
      reward: USER_PLANS.find(p => p.id === userData.planId)?.taskReward || 2,
      description: `Complete ${type} task`,
      platform: ['Instagram', 'Facebook', 'YouTube', 'Twitter'][Math.floor(Math.random() * 4)]
    }));
    setTasks(mockTasks);
  };

  const loadStats = async () => {
    // In production, fetch from database
    setStats({ todayEarnings: 125, tasksCompleted: 15, balance: userData?.balance || 0 });
  };

  const loadWithdrawals = async () => {
    // Mock withdrawal history
    setWithdrawals([
      { id: 1, amount: 500, method: 'JazzCash', status: 'completed', date: '2026-02-10' },
      { id: 2, amount: 1000, method: 'Easypaisa', status: 'pending', date: '2026-02-13' }
    ]);
  };

  const completeTask = async (taskId) => {
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;
    
    const newBalance = stats.balance + task.reward;
    
    // Update user balance in database
    const userRef = ref(database, `users/${user.uid}`);
    await update(userRef, { balance: newBalance });
    
    // Log task completion
    const taskRef = push(ref(database, 'tasks'));
    await set(taskRef, {
      userId: user.uid,
      taskType: task.type,
      reward: task.reward,
      completedAt: new Date().toISOString(),
      status: 'completed'
    });
    
    setStats({ ...stats, balance: newBalance, tasksCompleted: stats.tasksCompleted + 1, todayEarnings: stats.todayEarnings + task.reward });
  };

  const handleLogout = async () => {
    await signOut(auth);
    setView('landing');
  };

  const currentPlan = USER_PLANS.find(p => p.id === userData.planId);

  return (
    <>
      <nav className="navbar">
        <div className="logo">Z1 JOB</div>
        <div className="nav-buttons">
          <button className="btn btn-secondary" onClick={handleLogout}>Logout</button>
        </div>
      </nav>
      
      <div className="dashboard">
        <h1 style={{ fontSize: '2.5rem', marginBottom: '2rem', color: '#FFD700' }}>Welcome, {userData?.username}! 👋</h1>
        
        <div className="stats-grid">
          <div className="card stat-card">
            <div className="stat-value">{stats.todayEarnings}</div>
            <div className="stat-label">Today's Earnings (Rs)</div>
          </div>
          
          <div className="card stat-card">
            <div className="stat-value">{stats.tasksCompleted}</div>
            <div className="stat-label">Tasks Completed</div>
          </div>
          
          <div className="card stat-card">
            <div className="stat-value">{stats.balance}</div>
            <div className="stat-label">Total Balance (Rs)</div>
          </div>
          
          <div className="card stat-card">
            <div className="stat-value">{currentPlan?.name}</div>
            <div className="stat-label">Current Plan</div>
            <button className="btn btn-primary" style={{ marginTop: '1rem', fontSize: '0.9rem' }}>Upgrade</button>
          </div>
        </div>
        
        <div className="task-board">
          <h2 style={{ fontSize: '2rem', marginBottom: '1.5rem', color: '#FFD700' }}>Available Tasks</h2>
          {tasks.map(task => (
            <div key={task.id} className="task-item">
              <div className="task-info">
                <h4>{task.type} - {task.platform}</h4>
                <p style={{ color: '#B0B0B0' }}>{task.description}</p>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div className="task-reward">+Rs {task.reward}</div>
                <button className="btn btn-primary" style={{ marginTop: '0.5rem', fontSize: '0.9rem' }} onClick={() => completeTask(task.id)}>
                  Complete Task
                </button>
              </div>
            </div>
          ))}
        </div>
        
        <div style={{ marginTop: '3rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
            <h2 style={{ fontSize: '2rem', color: '#FFD700' }}>Withdrawal History</h2>
            <button className="btn btn-primary" onClick={() => setShowWithdrawModal(true)}>Request Withdrawal</button>
          </div>
          
          <div className="table-container">
            <table>
              <thead>
                <tr>
                  <th>Amount</th>
                  <th>Method</th>
                  <th>Status</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                {withdrawals.map(w => (
                  <tr key={w.id}>
                    <td>Rs {w.amount}</td>
                    <td>{w.method}</td>
                    <td>
                      <span className={`badge ${w.status === 'completed' ? 'badge-popular' : 'badge-featured'}`}>
                        {w.status}
                      </span>
                    </td>
                    <td>{w.date}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
      {showWithdrawModal && <WithdrawModal onClose={() => setShowWithdrawModal(false)} balance={stats.balance} userId={user.uid} />}
    </>
  );
}

// Withdraw Modal Component
function WithdrawModal({ onClose, balance, userId }) {
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState('JazzCash');
  const [accountInfo, setAccountInfo] = useState('');

  const handleWithdraw = async () => {
    if (parseInt(amount) < 100) {
      alert('Minimum withdrawal is Rs 100');
      return;
    }
    
    if (parseInt(amount) > balance) {
      alert('Insufficient balance');
      return;
    }
    
    const withdrawRef = push(ref(database, 'withdrawals'));
    await set(withdrawRef, {
      userId,
      amount: parseInt(amount),
      method,
      accountInfo,
      status: 'pending',
      requestDate: new Date().toISOString()
    });
    
    alert('Withdrawal request submitted!');
    onClose();
  };

  return (
    <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.8)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 9999 }}>
      <div className="card" style={{ maxWidth: '500px', width: '90%' }}>
        <h2 style={{ color: '#FFD700', marginBottom: '1.5rem' }}>Request Withdrawal</h2>
        
        <div className="input-group">
          <label>Amount (Rs)</label>
          <input type="number" min="100" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="Minimum Rs 100" />
          <small style={{ color: '#B0B0B0' }}>Available: Rs {balance}</small>
        </div>
        
        <div className="input-group">
          <label>Payment Method</label>
          <select value={method} onChange={(e) => setMethod(e.target.value)}>
            <option>JazzCash</option>
            <option>Easypaisa</option>
            <option>Bank Transfer</option>
            <option>Paiker</option>
          </select>
        </div>
        
        <div className="input-group">
          <label>Account Number / Details</label>
          <input type="text" value={accountInfo} onChange={(e) => setAccountInfo(e.target.value)} placeholder="Enter account details" />
        </div>
        
        <div style={{ display: 'flex', gap: '1rem', marginTop: '1.5rem' }}>
          <button className="btn btn-secondary" style={{ flex: 1 }} onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" style={{ flex: 1 }} onClick={handleWithdraw}>Submit Request</button>
        </div>
      </div>
    </div>
  );
}

// Admin Panel Component
function AdminPanel({ setView }) {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [users, setUsers] = useState([]);
  const [withdrawals, setWithdrawals] = useState([]);
  const [campaigns, setCampaigns] = useState([]);
  const [stats, setStats] = useState({ totalUsers: 0, totalEarnings: 0, pendingWithdrawals: 0, activeCampaigns: 0 });

  useEffect(() => {
    loadAdminData();
  }, []);

  const loadAdminData = async () => {
    // Mock data - in production, fetch from Firebase
    setStats({ totalUsers: 1523, totalEarnings: 125000, pendingWithdrawals: 15, activeCampaigns: 42 });
    
    setUsers([
      { id: 'user1', username: 'john_doe', email: 'john@example.com', plan: 'Gold', balance: 1500, fraudScore: 5, status: 'active' },
      { id: 'user2', username: 'jane_smith', email: 'jane@example.com', plan: 'Platinum', balance: 3200, fraudScore: 0, status: 'active' }
    ]);
    
    setWithdrawals([
      { id: 'w1', username: 'john_doe', amount: 500, method: 'JazzCash', status: 'pending', requestDate: '2026-02-13' },
      { id: 'w2', username: 'jane_smith', amount: 1000, method: 'Bank', status: 'pending', requestDate: '2026-02-12' }
    ]);
  };

  const approveWithdrawal = async (withdrawalId) => {
    // Update withdrawal status in database
    alert(`Withdrawal ${withdrawalId} approved!`);
    loadAdminData();
  };

  const handleLogout = async () => {
    await signOut(auth);
    setView('landing');
  };

  return (
    <>
      <nav className="navbar">
        <div className="logo">Z1 JOB Admin</div>
        <div className="nav-buttons">
          <button className="btn btn-secondary" onClick={handleLogout}>Logout</button>
        </div>
      </nav>
      
      <div className="admin-panel">
        <h1 style={{ fontSize: '2.5rem', marginBottom: '2rem', color: '#FFD700' }}>Admin Dashboard</h1>
        
        <div className="stats-grid">
          <div className="card stat-card">
            <div className="stat-value">{stats.totalUsers}</div>
            <div className="stat-label">Total Users</div>
          </div>
          
          <div className="card stat-card">
            <div className="stat-value">{stats.totalEarnings.toLocaleString()}</div>
            <div className="stat-label">Total Earnings (Rs)</div>
          </div>
          
          <div className="card stat-card">
            <div className="stat-value">{stats.pendingWithdrawals}</div>
            <div className="stat-label">Pending Withdrawals</div>
          </div>
          
          <div className="card stat-card">
            <div className="stat-value">{stats.activeCampaigns}</div>
            <div className="stat-label">Active Campaigns</div>
          </div>
        </div>
        
        <div className="admin-tabs">
          <button className={`admin-tab ${activeTab === 'dashboard' ? 'active' : ''}`} onClick={() => setActiveTab('dashboard')}>Dashboard</button>
          <button className={`admin-tab ${activeTab === 'users' ? 'active' : ''}`} onClick={() => setActiveTab('users')}>Users</button>
          <button className={`admin-tab ${activeTab === 'withdrawals' ? 'active' : ''}`} onClick={() => setActiveTab('withdrawals')}>Withdrawals</button>
          <button className={`admin-tab ${activeTab === 'campaigns' ? 'active' : ''}`} onClick={() => setActiveTab('campaigns')}>Campaigns</button>
        </div>
        
        {activeTab === 'dashboard' && (
          <div className="card">
            <h2 style={{ color: '#FFD700', marginBottom: '1.5rem' }}>Platform Analytics</h2>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={[
                { name: 'Mon', earnings: 4000, users: 24 },
                { name: 'Tue', earnings: 3000, users: 19 },
                { name: 'Wed', earnings: 5000, users: 32 },
                { name: 'Thu', earnings: 4500, users: 28 },
                { name: 'Fri', earnings: 6000, users: 41 },
                { name: 'Sat', earnings: 5500, users: 38 },
                { name: 'Sun', earnings: 7000, users: 45 }
              ]}>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis dataKey="name" stroke="#B0B0B0" />
                <YAxis stroke="#B0B0B0" />
                <Tooltip contentStyle={{ background: '#1A1A1A', border: '1px solid #C9A227' }} />
                <Legend />
                <Line type="monotone" dataKey="earnings" stroke="#FFD700" strokeWidth={3} />
                <Line type="monotone" dataKey="users" stroke="#10B981" strokeWidth={3} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
        
        {activeTab === 'users' && (
          <div className="table-container">
            <table>
              <thead>
                <tr>
                  <th>Username</th>
                  <th>Email</th>
                  <th>Plan</th>
                  <th>Balance</th>
                  <th>Fraud Score</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map(user => (
                  <tr key={user.id}>
                    <td>{user.username}</td>
                    <td>{user.email}</td>
                    <td><span className="badge badge-vip">{user.plan}</span></td>
                    <td>Rs {user.balance}</td>
                    <td>{user.fraudScore}</td>
                    <td><span className={`badge ${user.status === 'active' ? 'badge-popular' : 'badge-featured'}`}>{user.status}</span></td>
                    <td>
                      <button className="btn btn-secondary" style={{ fontSize: '0.8rem', padding: '0.5rem 1rem' }}>Edit</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        
        {activeTab === 'withdrawals' && (
          <div className="table-container">
            <table>
              <thead>
                <tr>
                  <th>User</th>
                  <th>Amount</th>
                  <th>Method</th>
                  <th>Status</th>
                  <th>Date</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {withdrawals.map(w => (
                  <tr key={w.id}>
                    <td>{w.username}</td>
                    <td>Rs {w.amount}</td>
                    <td>{w.method}</td>
                    <td><span className="badge badge-featured">{w.status}</span></td>
                    <td>{w.requestDate}</td>
                    <td>
                      <button className="btn btn-primary" style={{ fontSize: '0.8rem', padding: '0.5rem 1rem' }} onClick={() => approveWithdrawal(w.id)}>
                        Approve
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  );
}

// Advertiser Dashboard Component
function AdvertiserDashboard({ user, userData, setView }) {
  const [campaigns, setCampaigns] = useState([]);
  const [stats, setStats] = useState({ totalSpent: 0, activeCampaigns: 0, tasksCompleted: 0 });

  useEffect(() => {
    loadCampaigns();
  }, [user]);

  const loadCampaigns = async () => {
    // Mock campaigns
    setCampaigns([
      { id: 'c1', name: 'Instagram Growth', budget: 5000, spent: 2300, tasksCompleted: 230, totalTasks: 500, status: 'active' },
      { id: 'c2', name: 'YouTube Channel', budget: 10000, spent: 8500, tasksCompleted: 425, totalTasks: 500, status: 'active' }
    ]);
    setStats({ totalSpent: 10800, activeCampaigns: 2, tasksCompleted: 655 });
  };

  const handleLogout = async () => {
    await signOut(auth);
    setView('landing');
  };

  return (
    <>
      <nav className="navbar">
        <div className="logo">Z1 JOB Advertiser</div>
        <div className="nav-buttons">
          <button className="btn btn-secondary" onClick={handleLogout}>Logout</button>
        </div>
      </nav>
      
      <div className="dashboard">
        <h1 style={{ fontSize: '2.5rem', marginBottom: '2rem', color: '#FFD700' }}>Advertiser Dashboard</h1>
        
        <div className="stats-grid">
          <div className="card stat-card">
            <div className="stat-value">{stats.totalSpent.toLocaleString()}</div>
            <div className="stat-label">Total Spent (Rs)</div>
          </div>
          
          <div className="card stat-card">
            <div className="stat-value">{stats.activeCampaigns}</div>
            <div className="stat-label">Active Campaigns</div>
          </div>
          
          <div className="card stat-card">
            <div className="stat-value">{stats.tasksCompleted}</div>
            <div className="stat-label">Tasks Completed</div>
          </div>
          
          <div className="card stat-card">
            <button className="btn btn-primary" style={{ width: '100%' }}>Create Campaign</button>
          </div>
        </div>
        
        <div style={{ marginTop: '3rem' }}>
          <h2 style={{ fontSize: '2rem', marginBottom: '1.5rem', color: '#FFD700' }}>Your Campaigns</h2>
          
          {campaigns.map(campaign => (
            <div key={campaign.id} className="card" style={{ marginBottom: '1.5rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                <h3 style={{ color: '#FFD700', fontSize: '1.5rem' }}>{campaign.name}</h3>
                <span className={`badge ${campaign.status === 'active' ? 'badge-popular' : 'badge-featured'}`}>{campaign.status}</span>
              </div>
              
              <div style={{ marginBottom: '1rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                  <span>Budget Progress</span>
                  <span>Rs {campaign.spent} / Rs {campaign.budget}</span>
                </div>
                <div style={{ width: '100%', height: '10px', background: '#333', borderRadius: '5px', overflow: 'hidden' }}>
                  <div style={{ width: `${(campaign.spent / campaign.budget) * 100}%`, height: '100%', background: 'linear-gradient(90deg, #C9A227, #FFD700)' }}></div>
                </div>
              </div>
              
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div>
                  <div style={{ color: '#B0B0B0', fontSize: '0.9rem' }}>Tasks Completed</div>
                  <div style={{ fontSize: '1.5rem', fontWeight: '700', color: '#10B981' }}>{campaign.tasksCompleted} / {campaign.totalTasks}</div>
                </div>
                <div>
                  <div style={{ color: '#B0B0B0', fontSize: '0.9rem' }}>Completion Rate</div>
                  <div style={{ fontSize: '1.5rem', fontWeight: '700', color: '#FFD700' }}>{((campaign.tasksCompleted / campaign.totalTasks) * 100).toFixed(1)}%</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
